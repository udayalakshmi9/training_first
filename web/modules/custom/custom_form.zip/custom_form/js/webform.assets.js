/**
 * @file
 * This an empty placeholder file that is replaced with custom JavaScript.
 *
 * @see webform_js_alter()
 * @see _webform_asset_alter()
 * @see \Drupal\webform\WebformSubmissionForm::form
 */
