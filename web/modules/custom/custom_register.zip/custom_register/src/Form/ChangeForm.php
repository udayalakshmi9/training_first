<?php

namespace Drupal\custom_register\Form;


use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Config\ConfigFactoryInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

use Drupal\Core\Url;


use Symfony\Component\HttpFoundation\RedirectResponse;


class ChangeForm extends ConfigFormBase {

  public  $uid;
  
  public function getFormId() {
    return 'custom_register_change_form';
  }

 protected function getEditableConfigNames()
    {
        return [
        'custom_register.display',
        ];
    }
  public function buildForm(array $form, FormStateInterface $form_state) {
	  
	  
     $record = array();
	
	 //echo $uid;
	 $path = \Drupal::request()->getpathInfo();
$arg  = explode('/',$path);
 
	 //$uid =$_GET['uid']= \Drupal::request()->query->get('uid'); //echo $uid;exit;
	 
	 $uid=$arg[3];
    if ($uid) {
        
	  
	  
	  $record = \Drupal::service('config.factory')->getEditable('custom_register.settings')->get($uid);
		
}
$config = \Drupal::service('config.factory')->getEditable('custom_register.settings');


$form['username'] = [
       '#type' => 'textfield',
      '#title' => $this->t('username'),
      '#description' => $this->t('Email, #type = textfield'),
	   '#default_value' => (isset($record['username']) && $uid) ? $record['username']:'',
      
    ];

    // Email.
    $form['email'] = [
      '#type' => 'email',
      '#title' => $this->t('Email'),
      '#description' => $this->t('Email, #type = email'),
	   '#default_value' => (isset($record['email']) && $uid) ? $record['email']:'',
    ];
	 // password.
   
   // Password.
    $form['password'] = [
      '#type' => 'password',
      '#title' => $this->t('Password'),
	  
      '#description' => 'Password, #type = password',
	  '#default_value' => (isset($record['password']) && $uid) ? $record['password']:'',
    ];

   

  $form['uid'] = [
       '#type' => 'textfield',
      '#title' => $this->t('uid'),
      '#description' => $this->t('uid, #type = textfield'),
	   '#default_value' => $uid,
      
    ];
   

   
    $form['actions'] = [
      '#type' => 'actions',
      'submit' => [
        '#type' => 'submit',
		
        '#value' => $this->t('Submit'),
      ],
    ];

    return $form;
  }
  
  

 /* public function submitForm(array &$form, FormStateInterface $form_state) {
    // Find out what was submitted.
    $values = $form_state->getValues();
	$a=array();$b=array();
	
    foreach ($values as $key => $value) {
      $label = isset($form[$key]['#title']) ? $form[$key]['#title'] : $key;

      // Many arrays return 0 for unselected values so lets filter that out.
      if (is_array($value)) {
        $value = array_filter($value);
      }

      // Only display for controls that have titles and values.
      if ($value && $label) {
        $display_value = is_array($value) ? preg_replace('/[\n\r\s]+/', ' ', print_r($value, 1)) : $value;
        $message = $this->t('Value for %title: %value', ['%title' => $label, '%value' => $display_value]);
        $this->messenger()->addMessage($message);
		//$a[]= array('%title' => $label, '%value' => $display_value);
		
		
		


    
      }
    }
	  foreach ($values as $key => $value) {
	  if ($key=='username' || $key== 'email' || $key =='password')
	  {
		  array_push($a, $key);
		  array_push($b, $value);
	  }
	  }
	$myuid = uniqid('gfg');
	$c = array_combine($a, $b);
	$d= array($myuid[$c]);
	$config = \Drupal::service('custom_register.register')->savetocinfig($c);
  }
public function buildForm(array $form, FormStateInterface $form_state) {
    $config = $this->config('your_module.settings');
    $form['your_message'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Your message'),
      '#default_value' => $config->get('variable_name'),
    ];
    return parent::buildForm($form, $form_state);
  }

  /**
   * {@inheritdoc}
   
   
   */
   
    //$config->get('password')
   
   /*public function getusername($uid)
	{
		
		$config = \Drupal::service('config.factory')->getEditable('custom_register.settings');
		$s=$config->get('id');
		if (strpos($s, '2f5f') !== false) {
    echo 'true';
	return $config->get('id');
}
	
	}*/
  public function submitForm(array &$form, FormStateInterface $form_state) {
	   
    $d=array();
	
	
	$field=$form_state->getValues();
    $username=$field['username'];
    //echo "$name";
    $password=$field['password'];
    $email=$field['email'];
	$id=$field['uid'];
    /* if ($id) {
          $field  = array(
              'username'   => $name,
              'password' =>  $newpassword,
              'email' =>  $email,
              
          );
	 }*/
		  
		   $config = \Drupal::service('config.factory')->getEditable('custom_register.settings');
		   
		
          $field  = array(
              'username'   => $username,
              'password' =>  $password,
              'email' =>  $email,
              
          );
	  
	
	$d=array($id=>
		$field);
		
		//$config->set('password', $d[$uid]['newpassword'])
			//->save();
		$config = \Drupal::service('custom_register.register')->savetoeditcinfig($d);	
			//parent::submitForm($form, $form_state);
         
          //drupal_set_message("succesfully updated");
         
		 
		 
		
      }
 
}
